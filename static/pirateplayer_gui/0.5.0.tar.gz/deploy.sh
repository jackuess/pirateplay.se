srv_dir="/srv/http/pirateplay/static/pirateplayer_gui/"
version="0.5.0"

bsdtar -cf ${version}.tar.gz *
md5_sum=`md5sum ${version}.tar.gz | cut -d " " -f1`
mv ${version}.tar.gz $srv_dir

echo "${version} $md5_sum ${version}.tar.gz" | cat - ${srv_dir}pkglist > temp && mv temp ${srv_dir}pkglist
